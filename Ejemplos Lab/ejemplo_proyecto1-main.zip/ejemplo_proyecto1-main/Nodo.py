class Nodo: 
    def __init__(self):
        self.siguiente = None
        self.anterior = None